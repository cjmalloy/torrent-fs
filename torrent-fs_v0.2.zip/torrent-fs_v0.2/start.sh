#!/bin/bash

java -jar torrent-fs.jar -d ./cache -s
